import "./styles.css";
import * as GetData from "./data-business";
import * as Utils from "./utils";
import * as UtilsExtra from "./utils-extra";

GetData.getCharactersList().then(list => {

    const nodes = [];

    for (let item of list) {
        const node = Utils.createCharacterRow(item);
        node.onclick = function () {
            Utils.showCharacter(item)
        }
        nodes.push(node);
    }

    document.getElementById("root").innerText = "";

    for (let node of nodes) {
    document.getElementById("root").append(node);
    } 
});

GetData.getEpisodesList().then(list => {

    const nodes = [];

    for (let item of list) {
        const node = UtilsExtra.createEpisodesRow(item);
        node.onclick = function () {
            UtilsExtra.showEpisode(item);
            
        }
        nodes.push(node);
    }

    document.getElementById("root-episodes").innerText = "";

    for (let node of nodes) {
    document.getElementById("root-episodes").append(node);
    } 
});

GetData.getLocationsList().then(list => {

    const nodes = [];

    for (let item of list) {
        const node = UtilsExtra.createLocationRow(item);
        node.onclick = function () {
            UtilsExtra.showLocation(item)
        }
        nodes.push(node);
    }

    document.getElementById("root-locations").innerText = "";

    for (let node of nodes) {
    document.getElementById("root-locations").append(node);
    } 
});