import axios from "axios";

var getCharactersList = () => {

  return axios.get("https://rickandmortyapi.com/api/character")
    .then(response => {
      return response.data;
    })
    .then((data) => {
      return data.results;
    })
};

var getEpisodesList = () => {

  return axios.get("https://rickandmortyapi.com/api/episode")
  .then(response => {
    return response.data;
  })
  .then((data) => {
    return data.results;
  })
};

var getLocationsList = () => {

  return axios.get("https://rickandmortyapi.com/api/location")
  .then(response => {
    return response.data;
  })
  .then((data) => {
    return data.results;
  })
};



export { getCharactersList, getEpisodesList, getLocationsList };