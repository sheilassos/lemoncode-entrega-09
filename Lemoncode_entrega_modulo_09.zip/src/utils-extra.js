import * as Utils from "./utils"

const createEpisodesRow = (episode) => {
    const element = document.createElement("div");
    const link = createRowEpisodeText(episode);
    element.appendChild(link);
    element.className = "episode-row";
    return element;
};

const createRowEpisodeText = (episode) => {
    const element = document.createElement("span");
    element.append("· Ep " + episode.id + ": "+ episode.name);
    return element;
};

const showEpisode = (episode) => {
    console.log("episode", episode);
    const episodeDetail = document.getElementById("detail");
    episodeDetail.className = "visible";
    episodeDetail.innerHTML = "";
    episodeDetail.appendChild(Utils.createParagraph("Name: " + episode.name));
    episodeDetail.appendChild(Utils.createParagraph("Episode: " + episode.episode));
    episodeDetail.appendChild(Utils.createParagraph("Air Date: " + episode.air_date));
};

const createLocationRow = (location) => {
    const element = document.createElement("div");
    const link = createRowLocationText(location);
    element.appendChild(link);
    element.className = "location-row";
    return element;
};

const createRowLocationText = (location) => {
    const element = document.createElement("span");
    element.append("· "+ location.name);
    return element;
};

const showLocation = (location) => {
    console.log("location", location);
    const locationDetail = document.getElementById("detail");
    locationDetail.className = "visible";
    locationDetail.innerHTML = "";
    locationDetail.appendChild(Utils.createParagraph("Name: " + location.name));
    locationDetail.appendChild(Utils.createParagraph("Type: " + location.type));
    locationDetail.appendChild(Utils.createParagraph("Dimension: " + location.dimension));
};

export { createEpisodesRow, showEpisode, createLocationRow, showLocation }